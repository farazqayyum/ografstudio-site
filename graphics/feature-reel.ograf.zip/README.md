# OGraf Studio Feature Reel — coordinated OGraf graphic

This package contains one manifest and one controller for all template states. Load the manifest in an OGraf renderer; do not instantiate its internal templates independently.

Output: 1920 × 1080, 50 fps.

## Slots and states

### Reel ("reel")

- Studio: stateId "studio"; templateId "template-4b77f07d-0aa2-403d-8413-b5fd5c9fa8d9".
- Transition Logic: stateId "transitions"; templateId "template-2ccfa6be-b710-43fb-b619-73093aae6fe8".
- Shaders: stateId "shaders"; templateId "template-ab4255d3-fd31-4cb5-89ce-0f4caf83950e".
- Touch Controls: stateId "touch"; templateId "template-af2a4e8d-b31d-40ae-8396-59af5db6555d".
- Media: stateId "media"; templateId "template-4cecc446-3e5d-4ceb-b21e-25eaa314bbbb".
- Charts: stateId "charts"; templateId "template-865e553e-394e-43ef-801c-500891deee3f".
- AI: stateId "ai"; templateId "template-8537b531-cbfa-4fda-bdd1-3c79efe5bd16".
- Community: stateId "community"; templateId "template-4639ee18-1bce-45ae-90a3-b12a87223643".
- Off: stateId "" (an empty string).

### Ticker ("ticker")

- Ticker: stateId "ticker-on"; templateId "template-968f9521-ae01-4332-9c80-3c8338680030".
- Off: stateId "" (an empty string).

## Data and lifecycle

load prepares resources and stores selections without taking content on air. playAction takes the selected states; stopAction takes every slot out through its authored routes. updateAction updates the selected slot data and transitions on-air slots. Omitted slots retain their selection. Set stateId to an empty string ("") to take a slot out.

This graphic has one on-air Step. Use playAction({goto:0}) to apply or reapply all selected lanes. A plain playAction({}) advances standard Step navigation: the first Play enters, and another Play after the single on-air Step advances Out. Use stopAction for an explicit Out.

Whole-graphic Play preflights the complete selected batch before changing output. It prepares all incoming resources, waits for outgoing lanes and their exit barriers, then enters required parents before their dependents; independent lanes may enter together. Conflicting selections or preparation failures reject the batch while preserving working output. skipAnimation skips motion, not preparation or admission checks. Direct custom Take still requires its parent lanes to be fully On; it does not activate them automatically.

Each new state starts with its template defaults plus its named state preset. Explicit operator data and retained edits for that state take precedence. Provide per-slot data using the following structure:

```json
{
  "slots": {
    "reel": {
      "stateId": "studio",
      "data": {
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_baseColor": "#0d2b8c",
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_sheenColor": "#99d1ff",
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_shadowColor": "#03051a",
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_foldScale": 1.3,
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_foldDepth": 1,
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_flowSpeed": 0.34,
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_sheen": 1,
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_lightAngle": 120,
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_zoom": 1
      }
    }
  }
}
```

## Custom actions

Take or update one slot:

```json
{
  "id": "transition.take",
  "payload": {
    "slotId": "reel",
    "stateId": "studio",
    "data": {
      "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_baseColor": "#0d2b8c",
      "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_sheenColor": "#99d1ff",
      "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_shadowColor": "#03051a",
      "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_foldScale": 1.3,
      "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_foldDepth": 1,
      "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_flowSpeed": 0.34,
      "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_sheen": 1,
      "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_lightAngle": 120,
      "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_zoom": 1
    }
  }
}
```

Patch live data on the existing on-air instance without a template transition or ticker restart. Omit stateId (or use an empty string) to address the current state; a nonempty stateId is a guard. Off/leaving lanes reject the patch. Normal field bindings, data Rules and configured item/text update effects still apply:

```json
{
  "id": "transition.patch",
  "payload": {
    "slotId": "reel",
    "stateId": "studio",
    "data": {}
  }
}
```

Take one slot out through its authored route:

```json
{
  "id": "transition.out",
  "payload": {
    "slotId": "reel"
  }
}
```

Immediately clear one slot (omit slotId to clear all slots):

```json
{
  "id": "transition.clear",
  "payload": {
    "slotId": "reel"
  }
}
```

Action and loop choices include the available targets across each lane’s template states. Take the matching state on air before sending a command. Commands without any supported targets are omitted from this package’s controls.

A new request waits for resource readiness. When a transition is running, the latest pending request follows it. Shared component instances persist across template changes.

Take conditions are enforced before preparation and checked again before entry. Require On lanes must have finished entering; blocking lanes include preparation and their complete exit. A rejected Take does not change occupancy and is not queued for later revival. Establish any required lanes explicitly before taking a dependent. Take out with remains a separate Out/Clear dependency.

## Animation and rendering

The coordinator owns transition timing and plays authored per-layer IN and OUT tracks around the first on-air Step. Shaders, Text FX, clocks, masks, effects, data bindings and independent loops remain active. Loop groups support a data-controlled hold and pause/resume/next commands. Rules can run Take, Update, Out and Clear against lanes, respecting timing and dependencies. Template custom actions can trigger Rules and Text FX. Local data-writing actions and animated rule properties run on the shared frame clock, including delayed actions and deterministic replay. Template-specific later-step playback, audio/media cues, timeline/shader clips and custom-action loop activation remain unsupported; export refuses these actions.

Automatic count-up/count-down timers expose their existing clock:<encoded layer ID>:start, :pause, :reset and :restart actions through template.action. Start continues from the current value; Pause holds it; Reset returns to the initial value and stops; Restart returns to the initial value and runs. Manual count-up/count-down timers expose Reset and Restart to rearm alarms without changing the bound value; Start and Pause are omitted because only external updates advance the feed. Commands reach retained shared timers and every live runtime-collection row without restarting unrelated timers. System clocks keep reading their time source and are omitted from timer controls.

For non-real-time output, setActionsSchedule records OGraf actions with millisecond timestamps and goToTime evaluates the complete schedule deterministically. Send image/media URLs as absolute URLs or package-relative resource paths from this archive; paths are resolved against main.js, including nested data fields and scheduled actions.

## Default selections

Initial controls choose the first compatible state in stable lane order. Lanes requiring another lane On start Off, and conflicting or takeover states stay Off instead of displacing an earlier selection. Data-field defaults remain available while a lane is Off. Custom Take form suggestions are separate: they offer a valid state for the chosen lane even when that lane starts Off; choosing one does not change the initial whole-graphic selection.

```json
{
  "slots": {
    "reel": {
      "stateId": "studio",
      "data": {
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_baseColor": "#0d2b8c",
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_sheenColor": "#99d1ff",
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_shadowColor": "#03051a",
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_foldScale": 1.3,
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_foldDepth": 1,
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_flowSpeed": 0.34,
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_sheen": 1,
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_lightAngle": 120,
        "shader_layer_03a2c1e4_60c3_4c78_bea6_1d95c604b514_zoom": 1
      }
    },
    "ticker": {
      "stateId": "ticker-on",
      "data": {}
    }
  }
}
```
